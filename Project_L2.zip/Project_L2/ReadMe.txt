FINICHIU Eduard - Adelin
